import { OnInit,Component, Input } from "@angular/core";
import {EmployeeService} from './app.employeeService';



@Component({
    selector:'show-emp',
    templateUrl:'showEmployee.html'
})



 export class ShowEmployeeComponent implements OnInit {
    empId:number
    empName:string
    empSalary:number
    empDepartment:string
     constructor(private service:EmployeeService){}
     @Input()
     emparr:any[];
     ngOnInit()
     {
        this.service.getAllEmployee().subscribe((data:any)=>this.emparr=data);
      
     }
     deleteemployee(data:number)
      {
          this.emparr.splice(data,1)
      }
      addemp()
      {
         this.emparr.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment});
      }
      status:boolean=false;
      change()
      {
         this.status=true;
         this.addemp();
      }


 }