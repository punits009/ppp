import { Component } from "@angular/core";
import {Router} from '@angular/router';
@Component({
    selector:'log',
    templateUrl:'login.html'
})

export class LoginComponent{
    id:string;
    pass:string;
    aid:string="123";
    apass:string="1234";
    constructor(private router:Router){}
    check()
    {
        if(this.id==this.aid && this.pass==this.apass)
        {
            this.router.navigate(['wel']);
        }
        else{
            alert("invalid id and password");
        }
    }


}