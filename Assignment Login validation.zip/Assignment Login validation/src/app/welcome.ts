import { Component } from "@angular/core";

@Component({
    selector:'wel',
    templateUrl:'welcome.html'
})


export class Welcome{

}