﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { LoginComponent } from './login';
import {RouterModule, Routes, Router} from '@angular/router';
import {FormsModule} from '@angular/forms'
import {Welcome} from './welcome';
import {HttpClientModule} from '@angular/common/http';
const routes:Routes=[

    {path:'log',component:LoginComponent},
    {path:'wel',component:Welcome}

];

@NgModule({
    imports: [
        BrowserModule,RouterModule.forRoot(routes),FormsModule,HttpClientModule
        
    ],
    declarations: [
        AppComponent,LoginComponent,Welcome
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }
