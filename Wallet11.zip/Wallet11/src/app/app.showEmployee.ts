import { Component,} from "@angular/core";
import {EmployeeService} from './app.AccountService';
import {Account} from './models/Account';
import { Router } from "@angular/router";

@Component({
    selector:'show-emp',
    templateUrl:'showemployee.html'
})

export class ShowEmployeeComponent {
    constructor(private service:EmployeeService,private router:Router){}
    acc:Account[]=[];
    phone1:string
    accountHolder1:string
    balance1:number
    acc1:Account;
    index:number
    ngOnInit(): void {
        //throw new Error("Method not implemented.");
        this.service.getemployee().subscribe(
            res=>{
               this.acc=res

            },
            err=>{
                alert("an error has occurred")
            }
        )
       } 
       dele(i:number)
       {
           
           this.service.delete(this.acc[i].id).subscribe(data=>console.log(data),
           err=>alert("nO del"));
           this.acc.splice(i,1);

       }
       upda(i:number){

        this.index=i;
        this.phone1=this.acc[i].phone;
        this.accountHolder1=this.acc[i].accountHolder;
        this.balance1=this.acc[i].balance;
        
       }
       update()
       {
           
                    
           this.acc[this.index].phone=this.phone1;
           this.acc[this.index].accountHolder=this.accountHolder1;
           this.acc[this.index].balance=this.balance1;
           this.acc1={id:this.acc[this.index].id,phone:this.acc[this.index].phone,accountHolder:this.acc[this.index].accountHolder,balance:this.acc[this.index].balance};
            this.service.update(this.acc1,this.acc[this.index].id).subscribe(
            data=>console.log(data),
            err=>alert("Problem")
        )
            
       }
       ch=false;
       change()
       {
           this.ch=true;
       }
       fch()
       {
           this.ch=false;
       }


    
    
}