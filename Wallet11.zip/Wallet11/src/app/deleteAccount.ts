import { Component} from "@angular/core";
import {EmployeeService} from './app.AccountService';
import {Account} from './models/Account';

@Component({
    selector:'delete',
    templateUrl:'delete.html'
})

export class DeleteAccountComponent {
    er:Error
    id:number
    acc:Account
    constructor(private service:EmployeeService){}
    Delete()
    {
        if(confirm("Are you sure you wnat to delete"))
        {
       this.service.delete(this.id).subscribe(
        res=>{this.acc=res
       },
       err=>{
           this.er=err
       }
           
       )
    }
    }
    ch=false;
    change()
    {
        this.ch=true;
    }

    
    
}