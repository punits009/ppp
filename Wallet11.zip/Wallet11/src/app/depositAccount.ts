import { Component } from "@angular/core";
import {EmployeeService} from './app.AccountService';
import {Account} from "./models/Account";
import { DepositAndWithdraw } from "./models/DepositAndWithdraw";
@Component({
    selector:'deposit',
    templateUrl:'deposit.html'
})



export class DepositAccountComponent{
    constructor(private service:EmployeeService){}
    acc:number
    er:Error
    model:DepositAndWithdraw=
    {
        id:0,
        amount:0
    }
    deposit()
    {
        this.service.deposit(this.model).subscribe(
            res=>this.acc=res,
            err=>this.er=err
        )
    }
    ch=false;
    change()
    {
        this.ch=true;
    }
    fch()
    {
        this.ch=false;
    }
}