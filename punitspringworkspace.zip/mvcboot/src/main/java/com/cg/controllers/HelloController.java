package com.cg.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entities.*;
@RestController
public class HelloController {

	@GetMapping("/")
	public String hello()
	{
		return "hello";
	}
	
	@GetMapping("/products")
	public List<Product> getProduct(){
		List<Product> list=new LinkedList<Product>();
		list.add(new Product(101,"Phone","A Phone",12540.00));
		list.add(new Product(102,"Car","A Car",1012540.00));
		return list;
	}
}
