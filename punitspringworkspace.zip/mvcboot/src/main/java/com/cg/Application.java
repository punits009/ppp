package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	public static void main(String[] args) {
		
		/*this single line does follwing things
		 * 1. create AnnotationConfigApplicationContext
		 * 2.  it uses @ComponentScan for all child packages
		 *     2.1 It picks up hello Controller 
		 *     2.2Does request mapping to "/"
		 * 3.Reads Application Properties
		 *     3.1Found One Property server.port=3000
		 * 4.Launches Embedded Tomcat Server and deploy HelloController
		 * 5.Wait for you to terminate the process
		 * 
		 * */
		SpringApplication.run(Application.class,args);
	}
 
}
