package com.cg;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cg.entities.Country;

public class Main {
	
private static final String BASE_URL="http://localhost:5000/countries/";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestTemplate template=new RestTemplate();
		Country country=template.getForObject("http://localhost:5000/countries/code/IN", Country.class);
		System.out.println("Found Country:" +country.getName());
		Country cn=new Country("NN","Narnia","Antarctica","Wakad");
		ResponseEntity<String> s=template.postForEntity(BASE_URL+"/new", cn, String.class);
        System.out.println(s);
	}

}
