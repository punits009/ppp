package iocdemo1;

public class Address {
	private String line1, lin2, city;

	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(String line1, String lin2, String city) {
		super();
		this.line1 = line1;
		this.lin2 = lin2;
		this.city = city;
	}

	public String getLine1() {
		return line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLin2() {
		return lin2;
	}

	public void setLin2(String lin2) {
		this.lin2 = lin2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
