package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;
import com.cg.services.ProductService;

@RestController
public class ProductController {
	
	@Autowired private ProductService service;
	@GetMapping("/")
	@Transactional
	public String createSample() {
		Product p1=new Product(101,"Phone","A Phone",12540.00);
		Product p2=new Product(102,"Car","A Car",1012540.00);
		Product p3=new Product(103,"Bag","A Bag",2540.00);
		service.create(p1);
		service.create(p2);
		service.create(p3);
		
		return "Three products created";
	}
	@GetMapping("/list")
	public List<Product> getAll()
	{
		return service.getAll();
	}
	
	

}
