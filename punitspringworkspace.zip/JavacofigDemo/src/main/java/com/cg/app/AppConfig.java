package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDAO;
import com.cg.demo.EmployeeService;

@Configuration
// This is replacement of spring.xml
public class AppConfig {

	@Bean
	// Define a bean
	// synatx: public <className><BeanId>(){...........}
	public EmployeeDAO dao() {
		return new EmployeeDAO();
	}

	@Bean
	public EmployeeService service() {
		EmployeeService service = new EmployeeService();
		service.setDao(dao());// setter injection with Java Syntax
		return service;
	}

}
