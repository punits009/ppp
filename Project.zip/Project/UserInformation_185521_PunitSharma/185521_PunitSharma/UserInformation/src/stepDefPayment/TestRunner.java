package stepDefPayment;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/PaymentFeatures",glue="stepDefPayment",plugin="pretty")
public class TestRunner {
	
	/**

	 * Name-Punit Sharma.....empId-185521

	 * This testing contains 1seconds pause in each test case so please be patient

	 * The testing is performed according to the html pages provided

	 * Please check the path of the feature file and the stepDef

	 * Kindly check for the path of the web pages and change them accordingly

	 * The web driver used is Chrome. Kindly check its path and change accordingly

	 */

}
