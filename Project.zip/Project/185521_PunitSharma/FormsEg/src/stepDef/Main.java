package stepDef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Main {

	public static void main(String args[]) throws InterruptedException {
		
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:\\\\Lesson5-HTMLPages\\\\WorkingWithForms.html");
		
		WebElement element1=driver.findElement(By.id("txtUserName"));
		element1.sendKeys("arizusmani");
		
		WebElement element2=driver.findElement(By.id("txtPassword"));
		element2.sendKeys("capgemini");
		
		WebElement element3=driver.findElement(By.id("txtConfPassword"));
		element3.sendKeys("capgemini");
		
		WebElement element4=driver.findElement(By.id("rbMale"));
		element4.click();
		
		WebElement element5=driver.findElement(By.id("txtAddress"));
		element5.sendKeys("Hinjewadi");
		
		WebElement element6=driver.findElement(By.id("txtPhone"));
		element6.sendKeys("9999999999");
		
		WebElement element7=driver.findElement(By.name("City"));
		element7.sendKeys("Pune");
		
		WebElement element8=driver.findElement(By.id("m"));
		element8.click();
		
		WebElement element13=driver.findElement(By.id("mv"));
		element13.click();
		
		WebElement element9=driver.findElement(By.id("txtFirstName"));
		element9.sendKeys("Ariz");
		
		WebElement element10=driver.findElement(By.id("txtLastName"));
		element10.sendKeys("Usmani");
		
		WebElement element11=driver.findElement(By.id("DOB"));
		element11.sendKeys("1/1/1996");
		
		WebElement element12=driver.findElement(By.id("txtEmail"));
		element12.sendKeys("arizusmani007@gmail.com");
		
		Thread.sleep(10000);
		driver.quit();
	}
}
