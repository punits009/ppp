import { Component, OnInit } from "@angular/core";
import {EmployeeService} from './app.AccountService';
import { Account } from "./models/Account";
@Component({
    selector:'add-emp',
    templateUrl:'addAccount.html'
})


export class AddEmployeeComponent implements OnInit{
    
    id:number;
    phone:string;
    accountHolder:string;
    balance:number;
    acc:Account
    constructor(private service:EmployeeService){}
    ngOnInit(){}
    er:Error
    save()
    {
       
        var  account:Account=new Account(this.id,this.phone,this.accountHolder,this.balance);
        console.log(account);
        this.service.createAccount(account).subscribe(
            res=>
                this.acc=res,
            
            err=>this.er=err
        );     
    }   
    ch=false;
    change(){
        this.ch=true;
    } 
    fch()
    {
        this.ch=false;
    }
}