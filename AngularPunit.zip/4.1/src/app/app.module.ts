﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AddEmployeeComponent } from './addEmployee';
import { EmployeeService } from './app.employeeService';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { ShowEmployeeComponent } from './showEmployee';
@NgModule({
    imports: [
        BrowserModule,HttpClientModule,FormsModule
        
    ],
    declarations: [
        AppComponent,AddEmployeeComponent,ShowEmployeeComponent
		],
    providers: [EmployeeService ],
    bootstrap: [AppComponent]
})

export class AppModule { }
