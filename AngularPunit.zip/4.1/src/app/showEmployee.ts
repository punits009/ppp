import { OnInit,Component, Input } from "@angular/core";
import {EmployeeService} from './app.employeeService';



@Component({
    selector:'show-emp',
    templateUrl:'showEmployee.html'
})



 export class ShowEmployeeComponent implements OnInit {
  
     constructor(private service:EmployeeService){}
     @Input()
     emparr:any[];
     ngOnInit()
     {
        this.service.getAllEmployee().subscribe((data:any)=>this.emparr=data);
      
     }
     
      status:boolean=false;
      change()
      {
         this.status=true;
        
      }
      delete(data:number)
      {
         this.emparr.splice(data,1);
      }


 }