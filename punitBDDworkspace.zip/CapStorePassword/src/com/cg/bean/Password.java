package com.cg.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Password {
	WebDriver driver;
	
	@FindBy(id = "id")
	@CacheLookup
	WebElement email;
	
	@FindBy(id = "category")
	@CacheLookup
	WebElement category;
	
	@FindBy(id = "answer1")
	@CacheLookup
	WebElement answer1;
	
	@FindBy(id = "answer2")
	@CacheLookup
	WebElement answer2;
	
	
	@FindBy(id = "btn")
	@CacheLookup
	WebElement submit;

	public Password() {
		// TODO Auto-generated constructor stub
	}
	public Password(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email); 
	}
	public WebElement getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category.sendKeys(category);
	}
	public WebElement getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1.sendKeys(answer1);
	}
	public WebElement getAnswer2() {
		return answer2;
	}
	public void setAnswer2(String answer2) {
		this.answer2.sendKeys(answer2);
	}
	public WebElement getSubmit() {
		return submit;
	}
	public void setSubmit() {
		this.submit.click();
	}
	

}
