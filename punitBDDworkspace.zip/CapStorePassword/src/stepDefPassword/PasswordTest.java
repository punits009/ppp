package stepDefPassword;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.Password;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PasswordTest {
	WebDriver driver;
	private Password password;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver2.exe");//place to give path of chrome driver

		driver = new ChromeDriver();//creating an instance of chrome driver
	}
	
	@Given("^User on forgot Password Page$")
	public void user_on_forgot_Password_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		driver.get("D:\\Users\\punitsha\\Desktop\\Password.html");
		password=new Password(driver);
	}

	@When("^User enters 'invalid emailid'$")
	public void user_enters_invalid_emailid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		password.setEmail(" ");
		password.setSubmit();
		Thread.sleep(2000);
	}

	@Then("^show 'invalid emailid'$")
	public void show_invalid_emailid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String expected="ID should be filled";
		String actual=driver.switchTo().alert().getText();
		Assert.assertEquals(expected,actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters 'invalid category'$")
	public void user_enters_invalid_category() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		password.setEmail("punits009@gmail.com");
		password.setCategory(" ");
		password.setSubmit();
		Thread.sleep(2000);
	}

	@Then("^show 'invalid category'$")
	public void show_invalid_category() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String expected="Category should be filled";
		String actual=driver.switchTo().alert().getText();
		Assert.assertEquals(expected,actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters 'invalid answer(\\d+)'$")
	public void user_enters_invalid_answer(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		password.setEmail("punits009@gmail.com");
		password.setCategory("admin");
		password.setAnswer1(" ");
		password.setSubmit();
		Thread.sleep(2000);
	}

	@Then("^show 'invalid answer(\\d+)'$")
	public void show_invalid_answer(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String expected="Answer should be filled";
		String actual=driver.switchTo().alert().getText();
		Assert.assertEquals(expected,actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User clicks on Submit button with 'valid inputs'$")
	public void user_clicks_on_Submit_button_with_valid_inputs() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		password.setEmail("punits009@gmail.com");
		password.setCategory("admin");
		password.setAnswer1("Delhi");
		password.setAnswer2("Mamta");
		password.setSubmit();
		Thread.sleep(2000);
	}

	@Then("^Redirected to Success Page$")
	public void redirected_to_Success_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.get("D:\\Users\\punitsha\\Desktop\\success.html");
	}



}
