package stepDef;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {
	@Given("^I am not logged in as an adminstrator$")
	public void i_am_not_logged_in_as_an_adminstrator() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("I am not logged in");
	}

	@When("^I go to the adminstrative page$")
	public void i_go_to_the_adminstrative_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("I am going for adminstrative page");
	}

	@When("^I fill in the fields$")
	public void i_fill_in_the_fields(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    //throw new PendingException();
		System.out.println("I filled "+arg1.raw());
	}

	@When("^i press \"([^\"]*)\"$")
	public void i_press(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("i presssed="+arg1);
	}

	@Then("^i should be on the adminstrative page$")
	public void i_should_be_on_the_adminstrative_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("i am on adminstrative page");
	}

	@Then("^i should see log out$")
	public void i_should_see_log_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	    System.out.println("i am seeing Logout");
	}



}
