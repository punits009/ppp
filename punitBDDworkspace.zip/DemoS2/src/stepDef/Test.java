package stepDef;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {
	@Given("^I have login Page$")
	public void i_have_login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("LoginPage");
	}
	
		
	
	@When("^I enter punit(\\d+) and (\\d+)$")
	public void i_enter_punit_and(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("arg1 "+arg1+" and arg2 "+arg2);
	}
	@Then("^the result should be \"([^\"]*)\"$")
	public void the_result_should_be(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("result= "+arg1);
	}
	
		
	
	@When("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("arg1 "+arg1+" and arg2 "+arg2);
	}


	@When("^I enter (\\d+) and (\\d+)$")
	public void i_enter_and(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("arg1 "+arg1+" and arg2 "+arg2);
	}

	@When("^I enter punits(\\d+)@gmail\\.com and (\\d+)$")
	public void i_enter_punits_gmail_com_and(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("arg1 "+arg1+" and arg2 "+arg2);
	}



}
