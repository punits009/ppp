package stepDef;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {
	@Given("^The user selects and buy the product\\.$")
	public void the_user_selects_and_buy_the_product() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("The user selects and buy the product");
	}

	@When("^User modifies or buy the product and select purchase method as \"([^\"]*)\"$")
	public void user_modifies_or_buy_the_product_and_select_purchase_method_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Purchase method is="+arg1);
	}

	@Then("^Result of purchase is \"([^\"]*)\"$")
	public void result_of_purchase_is(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("The purchase method is "+arg1);
	}


}
