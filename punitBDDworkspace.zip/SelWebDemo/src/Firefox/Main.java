package Firefox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Main {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/html/employee.html");
		WebElement i=driver.findElement(By.id("eid"));
		i.sendKeys("12");
		WebElement e=driver.findElement(By.xpath("//table/tbody/tr[1]/td[2]"));
		System.out.println(e.getText());
//		System.out.println(e);
//		WebElement i=driver.findElement(By.id("eid"));
//		i.sendKeys("12");
		Thread.sleep(10000);
		driver.quit();
	}

}
