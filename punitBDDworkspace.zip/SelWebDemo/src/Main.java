import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Main {
	public static void main(String[] args) throws InterruptedException {
		String path="D:\\chromedriver2.exe";
		System.setProperty("webdriver.chrome.driver",path);
		WebDriver driver=new ChromeDriver();
		driver.get("file:///D:/page.html");
		WebElement e=driver.findElement(By.cssSelector("input[type='text'][id='uName']"));
		e.sendKeys("Punit");
		Thread.sleep(10000);
		driver.quit();

	}
}
