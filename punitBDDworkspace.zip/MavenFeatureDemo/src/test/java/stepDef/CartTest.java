package stepDef;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CartTest {
	@Given("^User searched for Lenovo laptop$")
	public void user_searched_for_Lenovo_laptop() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("^User searched for Lenovo laptop$");
	}

	@Given("^User selected the product$")
	public void user_selected_the_product() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("^User selected the product$");
	}

	@When("^User clicks on show cart$")
	public void user_clicks_on_show_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("^User clicks on show cart$");
	}

	@Then("^show list of product to user$")
	public void show_list_of_product_to_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("^show list of product to user$");
	}


}
