package stepDef;



import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.Register;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {
	private WebDriver driver;
	private Register register;
	
	@Before
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver2.exe" );
		driver= new ChromeDriver();
		driver.navigate().refresh();
	}
	@Given("^Student on 'Registration' Page$")
	public void student_on_Registration_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
//		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver2.exe" );
//		driver= new ChromeDriver();
		System.out.println(driver);
		driver.get("D:\\Users\\punitsha\\Desktop\\register.html");
		register= new Register(driver);
	}

	@When("^Student enters invalid name$")
	public void student_enters_invalid_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		register.setName("");
		register.setLoginButton();
		System.out.println(register.getName()); 
		
	}

	@Then("^Show 'invalid Student name'$")
	public void show_invalid_Student_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String expmsg=" *Please enter Name.";
		String actmsg=register.getNameErrMsg().getText();
		Assert.assertEquals(expmsg, actmsg);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^Student enters invalid address$")
	public void student_enters_invalid_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		register.setName("Punit");
		register.setAddress("");
		register.setLoginButton();
		System.out.println(register.getName());
	}

	@Then("^Show 'invalid Student Address'$")
	public void show_invalid_Student_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String expmsg=" *Please enter Address.";
		String actmsg=register.getAddressErrMsg().getText();
		Assert.assertEquals(expmsg, actmsg);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^Student enters invalid marks$")
	public void student_enters_invalid_marks() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		register.setName("Punit");
		register.setAddress("Pune");
		register.setMarks("");
		register.setLoginButton();
		System.out.println(register.getName());
	}

	@Then("^Show 'invalid Student marks'$")
	public void show_invalid_Student_marks() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String expmsg=" *Please enter Marks.";
		String actmsg=register.getMarksErrMsg().getText();
		Assert.assertEquals(expmsg, actmsg);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^Student enters valid details$")
	public void student_enters_valid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		register.setName("Punit");
		register.setAddress("Pune");
		register.setMarks("99");
		register.setLoginButton();
	}

	@Then("^Go to 'success'$")
	public void go_to_success() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
     	Thread.sleep(1000);
		driver.get("D:\\Users\\punitsha\\Desktop\\success.html");
	}


}
