package com.cg.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Register {
	
	WebDriver driver;
	@FindBy(name="name")
	@CacheLookup
	WebElement name;
	
	@FindBy(name="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="marks")
	@CacheLookup
	WebElement marks;
	
	@FindBy(id="nameErrMsg")
	@CacheLookup
	WebElement nameErrMsg;
	
	@FindBy(id="addressErrMsg")
	@CacheLookup
	WebElement addressErrMsg;

	@FindBy(id="marksErrMsg")
	@CacheLookup
	WebElement marksErrMsg;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement loginbtn;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks.sendKeys(marks);
	}

	public WebElement getNameErrMsg() {
		return nameErrMsg;
	}

	public void setNameErrMsg(WebElement nameErrMsg) {
		this.nameErrMsg = nameErrMsg;
	}

	public WebElement getAddressErrMsg() {
		return addressErrMsg;
	}

	public void setAddressErrMsg(WebElement addressErrMsg) {
		this.addressErrMsg = addressErrMsg;
	}

	public WebElement getMarksErrMsg() {
		return marksErrMsg;
	}

	public void setMarksErrMsg(WebElement marksErrMsg) {
		this.marksErrMsg = marksErrMsg;
	}

//	public WebElement getLoginbtn() {
//		return loginbtn;
//	}

	public void setLoginButton() {
		this.loginbtn.click();
	}
	
	public Register(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
}
