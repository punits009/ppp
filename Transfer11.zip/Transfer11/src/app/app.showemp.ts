import { Component, Output, Input } from "@angular/core";

@Component({
    selector: 'show-emp',
    templateUrl: 'app.showemp.html' 
})

export class ShowEmp{
    arr:any[]=[
       
    ];

    @Input()
    emparr:any[]
    
}

   


    
