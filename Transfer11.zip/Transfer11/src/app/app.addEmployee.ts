import {Component, ɵConsole} from '@angular/core';
@Component({
    selector:'add-emp',
    templateUrl:'app.add.html'
})
export class AddEmployeeComponent{
    empId:number;
    empName:string;
    empSalary:number;
    arr: any[]=[
        {empId:100,empName:"ABCD ",empSalary:30000.00
    }, {empId:101,empName:"BCD",empSalary:20000.00},
    {empId:102,empName:"CD",empSalary:15000.00}
    ]
    status:boolean=false;
    change()
    {
        this.status=true;
        this.arr.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary});
        this.empId=null;
    this.empName=null;
    this.empSalary=null;
    }


    
    }
