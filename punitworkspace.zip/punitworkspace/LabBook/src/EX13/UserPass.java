package EX13;

public interface UserPass {
	public void verify(String u,String p);

}
