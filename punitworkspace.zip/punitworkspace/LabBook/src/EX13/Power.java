package EX13;

//@FunctionalInterface
public interface Power {
	
		public double findPower(int a,int b);
		
	}


