package EX13;

public interface SpaceAdder {
	public void sadder(String st);

}
