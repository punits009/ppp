package E9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.io.*;
public class HmpwithCount {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    	System.out.println("enter the array");
		String st=br.readLine();
		char ch[]=st.toCharArray();
		HmpwithCount c=new HmpwithCount();
		c.count(ch);

	}
	public void count(char[] ch)
	{
		Map<Character,Integer > book=new TreeMap<Character,Integer>();
		List<Character> l=new ArrayList<Character>();
		Set<Character> s=new TreeSet<Character>();
		for(int i=0;i<ch.length;i++)
		{
			l.add(ch[i]);
			s.add(ch[i]);
		}
		for(Character a:s)
		{
			book.put(a,Collections.frequency(l, a));
		}
        System.out.println(book);
	}

}
