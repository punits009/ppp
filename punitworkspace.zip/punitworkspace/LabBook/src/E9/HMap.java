package E9;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class HMap {
	public static void main(String args[]) throws IOException
	{
		Map<Integer, String> book=new TreeMap<Integer,String>();
		System.out.println("Enter the vakues");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String s=br.readLine();
		book.put(1,s);
		s=br.readLine();
		book.put(2,s);
		s=br.readLine();
		book.put(3,s);
	    HMap h=new HMap();
	    h.sort(book);
		
		
	}
	
	public void sort(Map<Integer,String> book)
	{
		List<String> l=new ArrayList<String>(book.values());
	    Collections.sort(l);
	    System.out.println(l);
	}

}
