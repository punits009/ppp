package com.cg;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Demo1 {
	public static void main(String aes[])
	{
		//Executor Pattern
		
		
		
		Runnable r=()->System.out.println("th1 service pattern Run method executed by "+Thread.currentThread().getName());
		Runnable r1=()->System.out.println("th2 service pattern Run method executed by "+Thread.currentThread().getName());
		Runnable r2=()->System.out.println("th3 service pattern Run method executed by "+Thread.currentThread().getName());
		//ExecutorService executor=Executors.newSingleThreadExecutor();
		ExecutorService executor=Executors.newFixedThreadPool(8);
		executor.execute(r);
		executor.execute(r1);
		executor.execute(r2);
		executor.shutdown();
		

}
}
