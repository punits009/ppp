package com.cg;

import java.util.*;
import java.util.concurrent.*;

public class Demo5 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ShareMarket sm=new ShareMarket();
		ExecutorService executor=Executors.newFixedThreadPool(10);
		List<Future<Double>> acc=new ArrayList<>();
		for(int i=1;i<=5;i++)
		{
			Future<Double> f=executor.submit(sm);
			acc.add(f);
		}
		try
		{
			executor.awaitTermination(5, TimeUnit.SECONDS);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		executor.shutdown();
		double price=0.0;
		for(Future<Double> f:acc)
		{
			try
			{
				price=f.get();
			}
			catch(ExecutionException|InterruptedException e)
			{
				e.printStackTrace();
			}
			System.out.println("Price= "+price);
		}

	}

}
