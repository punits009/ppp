package cg;

import java.util.Scanner;

public class Squarediff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter n");
		int n=sc.nextInt();
		Squarediff s=new Squarediff();
		System.out.println(s.calculateDifference(n));
		
	}
	public int calculateDifference(int n)
	{
		
		int sosq=(n*(n+1)*(2*n+1))/6;
		int sqos=((n*(n+1))/2)*((n*(n+1))/2);
		return Math.abs(sosq-sqos);

	}

}
