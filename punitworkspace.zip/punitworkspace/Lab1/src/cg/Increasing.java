package cg;

import java.util.Arrays;
import java.util.Scanner;

public class Increasing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter n");
		int n=sc.nextInt();
		Increasing s=new Increasing();
		if(s.checkNumber(n))
			System.out.println(n+ " is an increasing number");
		
	}
	public boolean checkNumber(int n)
	{	
		String st=Integer.toString(n);
		boolean b=false;
		char c[]=st.toCharArray();
		Arrays.sort(c);
		String s=String.valueOf(c);
		if(st.equals(s))
			b=true;
		else
			b=false;
		return b;
	}

}

