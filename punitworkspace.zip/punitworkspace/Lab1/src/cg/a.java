package cg;

import java.util.Arrays;

public class a {
	public static void main(String a[])
	{
		int b[]=new int[] {1,2,3,4};
		System.out.println(Arrays.toString(b));
	}

}
