package cg;

public enum Size {
	Small(100),
	Medium(200),
	Large(300);
	private int ml;
	private Size(int ml)
	{
		this.ml=ml;
	}
   public int getml()
   {
	   return ml;
   }
}
