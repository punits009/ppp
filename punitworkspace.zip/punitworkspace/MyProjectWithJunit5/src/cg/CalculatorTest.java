package cg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

class CalculatorTest {
     static Calculator ob;
     @BeforeAll //junit 4 @BeforeClass
     public static void beforeallTest()
     {
    	 System.out.println("Before all test");
    	 ob=new Calculator();
     }
     @AfterAll //AfterClass in junit4
     public static void afterallTest()
     {
    	 System.out.println("After all test");
     }
     @BeforeEach //junit 4 @Before
     public void beforeEachTest()
     {
    	 System.out.println("Before each test");
    	 //ob=new Calculator();
    	 System.out.println(ob.idgenerator());
    	 
     }
     @AfterEach
     public void afterEachTest()//after in junit 4
     {
    	 System.out.println("After each test");
    	 //ob=null;
     }
	@Test
	void testadd() 
	{
		    System.out.println("Test Case testadd");
			assertEquals(9,ob.add(4,5));
		}
	@RepeatedTest(5)
	//@Test
	void testadd1() 
	{
		System.out.println("testadd 1");
			assertTrue((ob.add(4,5))>0);
			assertTrue((ob.add(4,-5))>=0);
		}
	@Disabled
	@Test
	void testidgen()
	{
		System.out.println("Test id generator");
		assertTrue(ob.idgenerator()>0);
	}
	
	
	}


