package cg;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;



class ValidatorTest {
	@ParameterizedTest
	@ValueSource(strings= {"racecar","radar","naman","nitin"})
	void test3(String data)
	{
		Validator ob=new Validator();
		System.out.println("test is palindrome with value " +data);
		assertTrue(ob.isPalindrome(data));
	}
	@ParameterizedTest
	@CsvSource({ "4, 5", "10, 20", "100, 500"})
	void test4(int a,int b)
	{
		Calculator ob=new Calculator();
		System.out.println("test add with values a= "+a+" b= "+b);
		assertTrue(ob.add(a, b)>0);
	}
	
	private static Stream<Arguments> testaddwithoutput()
	{
		return Stream.of(
				Arguments.of(4,5,9),
				Arguments.of(100,500,600));
				
	}
	@ParameterizedTest
	@EnumSource(Size.class)
	void withAllEnumValues(Size size) {
		// executed once for each time unit
		System.out.println("test for enum values="+size);
		Validator ob=new Validator();
		assertEquals(size.getml(),ob.getSizeinMl(size));
	}
	
	

	@TestFactory
    Collection<DynamicTest> dynamicTests() {
		Calculator ob=new Calculator();
		System.out.println("addition");
        return Arrays.asList(
            dynamicTest("addition", () -> assertEquals(ob.add(4, 5),9)),
            dynamicTest("idgen", () -> assertTrue(ob.idgenerator()>0))
        );
    }
	
	
	
	
	
	
	@ParameterizedTest
	@MethodSource("testaddwithoutput")
	void withMethodSource(int a,int b,int op)
	{
		Calculator ob=new Calculator();
		System.out.println("test add with values a="+a+" b= "+b+" output="+op);
		assertEquals(op,ob.add(a,b));
		
	}
	
	
	
	@Test
	void test1() {
		Validator ob=new Validator();
		String data="100";
		Assumptions.assumeTrue(data!=null);
		System.out.println("Assert false");
		assertTrue(ob.validateNo(data));
		data="abc";
		assertFalse(ob.validateNo(data));
		
	}
	@Test
	void test2() {
		Validator ob=new Validator();
		//assertTrue(ob.validateNo(null));
		//assertT(ob.validateNo("abc"));
		assertThrows(NullPointerException.class,()->ob.validateNo(null));
	}
	/*// ()->ob.validateNo(null)
	 * class ______implements Executable
	 * {
	 * public boolean execute()
	 * {
	 * return ob.validateNo(null);
	 * }
	 * }
	 */
 
}
