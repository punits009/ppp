package cg;

public class Validator {
	public int getSizeinMl(Size size)
	{
		System.out.println(size+" "+size.getml());
		return size.getml();
	}
	public boolean validateNo(String data)
	{
		return data.matches("\\d+");
	}
	public boolean isPalindrome(String data)
	{
		StringBuffer sb=new StringBuffer(data);
		String re=sb.reverse().toString();
		return data.equals(re);
		
	}

}
